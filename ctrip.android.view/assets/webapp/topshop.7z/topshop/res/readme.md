# 资源页面开发
## css目录
- main.css为全站公用的组件
- common.css为项目公用的组件
- style.css为项目的模块样式