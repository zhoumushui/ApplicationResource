// ------------------------------
// 优惠券列表
// ------------------------------
define(['libs', 'cUtilCryptBase64', 'cGuider', 'CarConfig', 'CarBasicPageView', 'cUtilHybrid', 'cUtility', 'CarUtil', 'CarModel', 'UILayer'], 
function (libs, Crypt, Guider, CarConfig, BasePageView, cUtilHybrid, cUtility, CarUtil, CarModel, UILayer) {
    

    //获得优惠券列表
    var getCarCouponList = CarModel.GetCarCouponList.getInstance();

	var View = BasePageView.extend({
        pageid: CarConfig.pageid("couponlist", false),
        hpageid: CarConfig.pageid("couponlist", true),

        onCreate: function () {

        },
        events: {
            //点击左边的筛选项
            'click #j_filter1': 'onClickFilterLeft',
            //点击右边的筛选项
            'click #j_filter2': 'onClickFilterRight',
            //点击某个筛选项
            'click .j_item': 'onClickSomeFilter',
            //点击某个优惠券实体
            'click .j_booking': 'onClickEntity'

        },
        //点击某个优惠券实体
        onClickEntity: function(e) {
            var $target = $(e.currentTarget).parents('.tic'),
                coupid = $target.data('cid'),
                entity;
            for(var i = 0, len = this.couponlist.length; i++){
                if(this.couponlist[i].promid == coupid){
                    entity = this.couponlist[i];
                }
            }
            //todo处理跳转
        },
        //点击某个筛选项
        onClickSomeFilter: function () {

        },
        /**
        * @description: 改变按钮状态
        * @param: 事件对象
        * @return: 返回是否展开
        */ 
        changeStatus: function(e){
            var $target = $(e.currentTarget),
                target = $target.find('.icon-car-arr');
            if(target.hasClass('icon-car-arr-down')){
                target.removeClass('icon-car-arr-down').addClass('icon-car-arr-up');
                return true;    
            }else{
                target.removeClass('icon-car-arr-up').addClass('icon-car-arr-down');    
                return false;
            }
        },
        resetTabStatus: function(name){
            this.$(name).find('.icon-car-arr-up').removeClass('icon-car-arr-up').addClass('icon-car-arr-down');
        },
        //点击左边的筛选项
        onClickFilterLeft: function (e) {
            var isOpen = this.changeStatus(e);
            var data = [{name:'今天天气不错',type:'1'}, {name:'今天天气不好',type:'2'}];

            if(isOpen){
                var html = _.template(Lizard.T('j_tabtpl'));
                this.els.tabcontainer.html(html({data: data}));  
            }else{
                this.els.tabcontainer.html('');
            }
            this.resetTabStatus('#j_filter2');
        },
        //点击右边的筛选项
        onClickFilterRight: function (e) {
            var isOpen = this.changeStatus(e);
            var data = [{name:'明天天气不错',type:'1'}, {name:'明天天气不好',type:'2'}];

            if(isOpen){
                var html = _.template(Lizard.T('j_tabtpl'));
                this.els.tabcontainer.html(html({data: data}));  
            }else{
                this.els.tabcontainer.html('');
            }
            this.resetTabStatus('#j_filter1');
        },
        onShow: function () {
            this.els = {
                container: this.$el.find('#j_container'),
                tpl: this.$el.find('#j_tpl'),
                tabcontainer: this.$el.find('#j_tabcontainer')
            }
            var self = this;

            this.headerview.set({
                title: '用车券',
                view: this,
                back: true,
                events: {
                    returnHandler: function () {
                        self.back();
                    }
                }
            });
            this.headerview.show();

            this.showLoading();
            getCarCouponList.excute(function (data) {
                this.hideLoading();
                if(data && data.couplist && data.couplist.length > 0){
                    var html = _.template(this.els.tpl.html());
                    this.els.container.html(html({data: data}));
                    this.couponlist = data.couplist;
                }else{
                    this.showToast({
                        datamodel: {
                            content: CarUtil.ERRMSG_CODE1
                        },
                        hideSec: 2000,
                        hideAction: function() {
                            self.back();
                        }
                    });
                }
            }, function () {
                this.hideLoading();
                this.showToast({
                    datamodel: {
                        content: CarUtil.ERRMSG_CODE1
                    },
                    hideSec: 2000,
                    hideAction: function() {
                        self.back();
                    }
                });
            }, false, this);
		},
        onHide: function () {
        }
	});
	return View;
});