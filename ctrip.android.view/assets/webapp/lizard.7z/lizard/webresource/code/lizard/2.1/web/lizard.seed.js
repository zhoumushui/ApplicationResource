/*
* Ctrip Lizard JavaScript Framework
* Copyright(C) 2008 - 2015, All rights reserved,ctrip.com.
* Date:2015-11-10 15:23:27
* tag:h-6.11-201511101523
*/
for(var scripts=document.getElementsByTagName("script")||[],reg=/lizard\.seed\.(src\.)*js.*$/gi,curPath="",i=0;i<scripts.length;i++){var src=scripts[i].getAttribute("src");if(src&&reg.test(src)){var filePath=src.replace(reg,"");curPath=filePath.substr(0,filePath.lastIndexOf("code/lizard"));break}}document.write("<script src='"+curPath+"code/lizard/libs/lizard.libs.js'></script>"),document.write("<script src='"+filePath+"lizard.common.js'></script>");