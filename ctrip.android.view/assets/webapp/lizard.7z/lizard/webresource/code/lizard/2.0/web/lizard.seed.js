/*
* Ctrip Lizard JavaScript Framework
* Copyright(C) 2008 - 2015, All rights reserved,ctrip.com.
* Date:2015-11-10 15:23:27
* tag:h-6.11-201511101523
*/
document.write("<script src='http://webresource.c-ctrip.com/code/lizard/2.0/web/lizard.seed.js'></script>");